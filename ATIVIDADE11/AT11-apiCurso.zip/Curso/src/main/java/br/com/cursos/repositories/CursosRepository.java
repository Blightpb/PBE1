package br.com.cursos.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.cursos.entities.Cursos;

public interface CursosRepository extends JpaRepository<Cursos, Long>{

}
