package br.com.cursos.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.cursos.entities.Alunos;
import br.com.cursos.services.AlunosService;
 
@RestController
@RequestMapping("/Alunos")
public class AlunosController {
	
	@Autowired
	private AlunosService AlunosService;
	
	@PostMapping
	public Alunos createAlunos(Alunos Alunos) {
		return AlunosService.saveAlunos(Alunos);
	}
	
	@GetMapping
	public List<Alunos> getAllAlunos(){
		return AlunosService.getAllAlunos();
	}
	@GetMapping ("/{id_alunos}")
	public Alunos getAlunos(@PathVariable Long id_alunos) {
		return AlunosService.getAlunosById(id_alunos);
	}
	@DeleteMapping("/{id_Editora}")
	public void deleteAlunos (@PathVariable Long id_alunos) {
		AlunosService.deleteAlunos(id_alunos);
	}

}