package br.com.cursos.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cursos.entities.Disciplinas;
import br.com.cursos.repositories.DisciplinasRepository;

@Service
public class DisciplinasService {
	
	@Autowired
	private DisciplinasRepository DisciplinasRepository;
	
	public Disciplinas saveDisciplinas(Disciplinas Disciplinas) {
		return DisciplinasRepository.save(Disciplinas);
	}
	
	public List<Disciplinas> getAllDisciplinas(){
		return DisciplinasRepository.findAll();
	}
	public Disciplinas getDisciplinasById (Long id_disciplinas) {
		return DisciplinasRepository.findById(id_disciplinas).orElse(null);
	}
	public void deleteDisciplinas(Long id_disciplinas) {
		DisciplinasRepository.deleteById(id_disciplinas);
	}
}