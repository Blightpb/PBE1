package br.com.cursos.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cursos.entities.Instrutores;
import br.com.cursos.repositories.InstrutoresRepository;

@Service
public class InstrutoresService {
	
	@Autowired
	private InstrutoresRepository InstrutoresRepository;
	
	public Instrutores saveInstrutores(Instrutores Instrutores) {
		return InstrutoresRepository.save(Instrutores);
	}
	
	public List<Instrutores> getAllInstrutores(){
		return InstrutoresRepository.findAll();
	}
	public Instrutores getInstrutoresById (Long id_instrutores) {
		return InstrutoresRepository.findById(id_instrutores).orElse(null);
	}
	public void deleteInstrutores(Long id_instrutores) {
		InstrutoresRepository.deleteById(id_instrutores);
	}
}