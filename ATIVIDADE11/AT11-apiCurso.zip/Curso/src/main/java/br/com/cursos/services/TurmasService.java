package br.com.cursos.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cursos.entities.Turmas;
import br.com.cursos.repositories.TurmasRepository;

@Service
public class TurmasService {
	
	@Autowired
	private TurmasRepository TurmasRepository;
	
	public Turmas saveTurmas(Turmas Turmas) {
		return TurmasRepository.save(Turmas);
	}
	
	public List<Turmas> getAllTurmas(){
		return TurmasRepository.findAll();
	}
	public Turmas getTurmasById (Long id_turmas) {
		return TurmasRepository.findById(id_turmas).orElse(null);
	}
	public void deleteTurmas(Long id_turmas) {
		TurmasRepository.deleteById(id_turmas);
	}
}