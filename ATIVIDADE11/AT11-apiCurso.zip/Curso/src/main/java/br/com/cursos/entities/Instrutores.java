package br.com.cursos.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_Instrutores")
public class Instrutores {

	@Column(name = "nome")
	private String nome;
	
	@Column(name = "email")
	private String email;
	
	@Column(name = "telefone")
	private int telefone;
	
	@Column(name = "especializacao")
	private String especializacao;
	
	@Column(name = "experiencia")
	private String experiencia;

	
	
	//construtores
	public Instrutores() {
		
	}
	public Instrutores (String nome, String email, int telefone, String especializacao, String experiencia) {
		this.nome = nome;
		this.email = email;
		this.telefone = telefone;
		this.especializacao = especializacao;	
		this.experiencia = experiencia;	
	}
	
	//getters e setters
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getTelefone() {
		return telefone;
	}
	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}
	public String getEspecializacao() {
		return especializacao;
	}
	public void setEspecializacao(String especializacao) {
		this.especializacao = especializacao;
	}
	public String getExperiencia() {
		return experiencia;
	}
	public void setExperiencia(String experiencia) {
		this.experiencia = experiencia;
	}
		
}