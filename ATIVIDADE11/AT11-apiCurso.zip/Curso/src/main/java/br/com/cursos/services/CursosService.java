package br.com.cursos.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cursos.entities.Cursos;
import br.com.cursos.repositories.CursosRepository;

@Service
public class CursosService {
	
	@Autowired
	private CursosRepository CursosRepository;
	
	public Cursos saveCursos(Cursos Cursos) {
		return CursosRepository.save(Cursos);
	}
	
	public List<Cursos> getAllCursos(){
		return CursosRepository.findAll();
	}
	public Cursos getCursosById (Long id_curso) {
		return CursosRepository.findById(id_curso).orElse(null);
	}
	public void deleteCursos(Long id_curso) {
		CursosRepository.deleteById(id_curso);
	}
}