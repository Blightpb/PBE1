package br.com.cursos.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import br.com.cursos.entities.Alunos;

public interface AlunosRepository extends JpaRepository<Alunos, Long>{

}