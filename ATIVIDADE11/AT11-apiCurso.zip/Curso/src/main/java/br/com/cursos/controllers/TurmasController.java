package br.com.cursos.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.cursos.entities.Turmas;
import br.com.cursos.services.TurmasService;
 
@RestController
@RequestMapping("/Turmas")
public class TurmasController {
	
	@Autowired
	private TurmasService TurmasService;
	
	@PostMapping
	public Turmas createTurmas(Turmas Turmas) {
		return TurmasService.saveTurmas(Turmas);
	}
	
	@GetMapping
	public List<Turmas> getAllTurmas(){
		return TurmasService.getAllTurmas();
	}
	@GetMapping ("/{id_turmas}")
	public Turmas getTurmas(@PathVariable Long id_Turmas) {
		return TurmasService.getTurmasById(id_Turmas);
	}
	@DeleteMapping("/{id_disciplinas}")
	public void deleteTurmas (@PathVariable Long id_Turmas) {
		TurmasService.deleteTurmas(id_Turmas);
	}
}