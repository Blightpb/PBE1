package br.com.cursos.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cursos.entities.Alunos;
import br.com.cursos.repositories.AlunosRepository;

@Service
public class AlunosService {
	
	@Autowired
	private AlunosRepository AlunosRepository;
	
	public Alunos saveAlunos(Alunos Alunos) {
		return AlunosRepository.save(Alunos);
	}
	
	public List<Alunos> getAllAlunos(){
		return AlunosRepository.findAll();
	}
	public Alunos getAlunosById (Long id_alunos) {
		return AlunosRepository.findById(id_alunos).orElse(null);
	}
	public void deleteAlunos(Long id_alunos) {
		AlunosRepository.deleteById(id_alunos);
	}
}