package br.com.cursos.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.cursos.entities.Instrutores;
import br.com.cursos.services.InstrutoresService;
 
@RestController
@RequestMapping("/Instrutores")
public class InstrutoresController {
	
	@Autowired
	private InstrutoresService InstrutoresService;
	
	@PostMapping
	public Instrutores createInstrutores(Instrutores Instrutores) {
		return InstrutoresService.saveInstrutores(Instrutores);
	}
	
	@GetMapping
	public List<Instrutores> getAllInstrutores(){
		return InstrutoresService.getAllInstrutores();
	}
	@GetMapping ("/{id_instrutores}")
	public Instrutores getInstrutores(@PathVariable Long id_instrutores) {
		return InstrutoresService.getInstrutoresById(id_instrutores);
	}
	@DeleteMapping("/{id_disciplinas}")
	public void deleteInstrutores (@PathVariable Long id_instrutores) {
		InstrutoresService.deleteInstrutores(id_instrutores);
	}

}