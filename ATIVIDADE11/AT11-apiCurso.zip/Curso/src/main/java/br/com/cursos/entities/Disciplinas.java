package br.com.cursos.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_Disciplinas")
public class Disciplinas {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id_disciplina;
	
	@Column(name = "nome")
	private String nome;
	
	@Column(name = "descricao")
	private String descricao;
	
	@Column(name = "carga_horaria")
	private int carga_horaria;
	
	//construtores
	public Disciplinas() {
		
	}
	public Disciplinas (Long id_disciplina, String nome, String descricao, int carga_horaria) {
		this.id_disciplina = id_disciplina;
		this.nome = nome;
		this.descricao = descricao;
		this.carga_horaria = carga_horaria;
		
	}
		
	//getters e setters

	public Long getId_disciplina() {
		return id_disciplina;
	}
	public void setId_disciplina(Long id_disciplina) {
		this.id_disciplina = id_disciplina;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public int getCarga_horaria() {
		return carga_horaria;
	}
	public void setCarga_horaria(int carga_horaria) {
		this.carga_horaria = carga_horaria;
	}
}