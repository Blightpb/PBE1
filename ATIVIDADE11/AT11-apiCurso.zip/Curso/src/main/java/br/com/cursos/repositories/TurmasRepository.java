package br.com.cursos.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.cursos.entities.Turmas;

public interface TurmasRepository extends JpaRepository<Turmas, Long>{

}