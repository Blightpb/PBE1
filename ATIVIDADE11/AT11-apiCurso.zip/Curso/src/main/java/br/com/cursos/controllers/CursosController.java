package br.com.cursos.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.cursos.entities.Cursos;
import br.com.cursos.services.CursosService;
 
@RestController
@RequestMapping("/Cursos")
public class CursosController {
	
	@Autowired
	private CursosService CursosService;
	
	@PostMapping
	public Cursos createCursos(Cursos Cursos) {
		return CursosService.saveCursos(Cursos);
	}
	
	@GetMapping
	public List<Cursos> getAllCursos(){
		return CursosService.getAllCursos();
	}
	@GetMapping ("/{id_curso}")
	public Cursos getCursos(@PathVariable Long id_cursos) {
		return CursosService.getCursosById(id_cursos);
	}
	@DeleteMapping("/{id_curso}")
	public void deleteCursos (@PathVariable Long id_cursos) {
		CursosService.deleteCursos(id_cursos);
	}

}