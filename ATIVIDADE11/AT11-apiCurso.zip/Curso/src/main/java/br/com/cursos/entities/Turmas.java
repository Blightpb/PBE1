package br.com.cursos.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "Turmas")
public class Turmas {

	@Column(name = "inicio")
	private int inicio;
	
	@Column(name = "termino")
	private int termino;
	
	@Column(name = "horario")
	private int horario;
	
	@Column(name = "vagas_disponiveis")
	private int vagas_disponiveis;
	
	//construtores
	public Turmas() {
		
	}
	public Turmas (int inicio, int termino, int horario, int vagas_disponiveis) {
		this.inicio = inicio;
		this.termino = termino;
		this.horario = horario;
		this.vagas_disponiveis = vagas_disponiveis;
	}
	
	//getters e setters

	public int getInicio() {
		return inicio;
	}
	public void setInicio(int inicio) {
		this.inicio = inicio;
	}
	public int getTermino() {
		return termino;
	}
	public void setTermino(int termino) {
		this.termino = termino;
	}
	public int getHorario() {
		return horario;
	}
	public void setHorario(int horario) {
		this.horario = horario;
	}
	public int getVagas_disponiveis() {
		return vagas_disponiveis;
	}
	public void setVagas_disponiveis(int vagas_disponiveis) {
		this.vagas_disponiveis = vagas_disponiveis;
	}
		
}