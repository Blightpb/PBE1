package prjPokemonV2;

public class Aplicacao {
	public static void main(String[] args) {
		Pokemon growlithe = new Pokemon ();
		growlithe.setNome("Growlithe");
		growlithe.setTipo("Fogo");
		growlithe.setNivel(1);
		growlithe.setHp1(100);
		growlithe.setDefesa1(50);
		
		Pokemon ponyta = new Pokemon();
		ponyta.setNome("Ponyta");
		ponyta.setTipo("Fogo");
		ponyta.setNivel(2);
		ponyta.setHp1(200);
		ponyta.setDefesa1(50);
		
		Pokemon magikarp = new Pokemon();
		magikarp.setNome("Magikarp");
		magikarp.setTipo("Água");
		magikarp.setNivel(3);
		magikarp.setHp1(300);
		magikarp.setDefesa1(50);
		
		Pokemon spheal = new Pokemon();
		spheal.setNome("Spheal");
		spheal.setTipo("Água");
		spheal.setNivel(4);
		spheal.setHp1(400);
		spheal.setDefesa1(50);
		
		Pokemon pidgey = new Pokemon();
		pidgey.setNome("Pidgey");
		pidgey.setTipo("Voador");
		pidgey.setNivel(5);
		pidgey.setHp1(500);
		pidgey.setDefesa1(50);
		
		Pokemon swablu = new Pokemon();
		swablu.setNome("Swablu");
		swablu.setTipo("Voador");
		swablu.setNivel(6);
		swablu.setHp1(600);
		swablu.setDefesa1(50);
		
	}	
}
