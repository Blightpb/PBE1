package prjPokemonV2;

public class PokemonAgua extends Pokemon {
	//metodos
	
	public void surfar() {
		System.out.println(this.getNome()+ " está surfando");
   }@Override
	public void canhaoAgua() {
		System.out.println(this.getNome() + " está atacando com canhão de água");
	}
}
