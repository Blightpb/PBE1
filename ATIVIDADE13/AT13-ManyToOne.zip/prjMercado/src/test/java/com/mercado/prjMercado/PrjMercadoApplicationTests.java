package com.mercado.prjMercado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjMercadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
