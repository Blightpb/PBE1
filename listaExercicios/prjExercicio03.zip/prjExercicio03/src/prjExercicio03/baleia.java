package prjExercicio03;

public class baleia extends Animal{
	
	//metodos
	public void nadar() {
		@Override
		System.out.println(this.nome + " está nadando");
	}

}
