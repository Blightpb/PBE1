package prjExercicio03;

public class Animal {
	
	//Atributos
		private String nome;
		private int idade;
		private String raca;
		
		//Construtores
		
		public Animal () {
		}
		public Animal (String Nome, int Idade, String Raca) {
			this.nome = Nome;
			this.idade= Idade;
			this.raca = Raca;
		}
		
		//metodos getters and setters
	public void setNome(String Nome) {
		  this.nome = Nome;
	  }
	public void setIdade(int Idade) {
		  this.idade = Idade;
	  }
	public void setRaca(String Raca) {
		  this.raca = Raca;
	  }
	public String getNome() {
		return nome;
	}
	public int getIdade() {
		return idade;
	}
	public String getRaca() {
		return raca;
	}
	
	//metodos
	
	public void nadar() {
		System.out.println(this.nome + "está nadando");
	}
	public void cacar() {
		System.out.println(this.nome + "está caçando");
	}
	
	
		
}


