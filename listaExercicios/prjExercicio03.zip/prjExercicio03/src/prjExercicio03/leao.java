package prjExercicio03;

public class leao extends Animal{
	
	//metodos
	public void cacar() {
		@Override
		System.out.println(this.nome + " está caçando");
	}

}

