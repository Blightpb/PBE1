package prjExercicio05;

public class ContaBancaria {
		//atributos
		private String titular;
		private int numero;
		private double saldo;
			
		//construtores
		public ContaBancaria() {
			
		}
		public ContaBancaria(String titular,int numero,double saldo ) {
		this.numero = numero;
		this.saldo = saldo;
		this.titular = titular;
		}
		
		//metodos getters e setters
		public String getTitular() {
			return titular;
		}
		public void setTitular(String titular) {
			this.titular = titular;
		}
		public int getNumero() {
			return numero;
		}
		public void setNumero(int numero) {
			this.numero = numero;
		}
		public double getSaldo() {
			return saldo;
		}
		public void setSaldo(double saldo) {
			this.saldo = saldo;
		}
		
		//metodos
		public void depositar() {
			System.out.println("vaor depositado");
		}
		public void sacar() {
			if(this.saldo >0) {
			System.out.println("Saque realizado");
			}
			else {
			System.out.println("Não há valor para ser depositado");
			}
		}
		
	}

