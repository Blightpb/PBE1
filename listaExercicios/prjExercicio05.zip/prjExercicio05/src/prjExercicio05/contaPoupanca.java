package prjExercicio05;

public class contaPoupanca extends ContaBancaria {
	private double taxaJuros;
	//metodos
	public void calcularJuros() {
		taxaJuros + saldo
	}
}
