package prjExercio02;

public class Livro {
	
	//Atributos
	
	private  String titulo;
	private  String autor;
	private int numPaginas;
	private double preco;
	
	//Construtores
	public Livro () {
	}
	
	public Livro (String Titulo, String Autor, int NumPaginas, double Preco) {
		this.titulo = Titulo;
		this.autor = Autor;
		this.numPaginas= NumPaginas;
		this.preco = Preco;
	}
	
	//metodos setters
	
	public void setTitulo (String Titulo) {
		this.titulo = Titulo;
	}
	public void setAutor (String Autor) {
		this.autor = Autor;		
	}
	public void setNumPaginas (int NumPaginas) {
		this.numPaginas = NumPaginas;		
	}
	public void setPreco (double Preco) {
		this.preco = Preco;	
	}
	
	//metodos
	
	public void aplicarDesconto() {
	
		this.preco -= 15;
		System.out.println(this.preco + " com o desconto");
	}
	public void exibirInfo () {
		System.out.println("título: " + this.titulo);
		System.out.println("Autor: " + this.autor);
		System.out.println("Número de páginas: " + this.numPaginas);
		System.out.println("Preço: " + this.preco);
	}
	
	public String getTitulo() {
		return titulo;
	}

	public String getAutor() {
		return autor;
	}

	public int getNumPaginas() {
		return numPaginas;
	}

	public double getPreco() {
		return preco;
	}

	
	
	}



 	


