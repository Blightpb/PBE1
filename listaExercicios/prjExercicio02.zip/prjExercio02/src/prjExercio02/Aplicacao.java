package prjExercio02;

public class Aplicacao {

	public static void main(String[] args) {
	
	Livro livroUm = new Livro();
	livroUm.exibirInfo();
	livroUm.setTitulo("A aventura da vaquinha");
	livroUm.setAutor ("Murilo Henrique");
	livroUm.setNumPaginas(200);
	livroUm.setPreco(20);
	livroUm.aplicarDesconto();
	livroUm.exibirInfo();
	
	Livro livroDois = new Livro();
	livroDois.exibirInfo();
	livroDois.setTitulo("Vaquinha pimposa");
	livroDois.setAutor ("Julia França");
	livroDois.setNumPaginas(300);
	livroDois.setPreco(30);
	livroDois.aplicarDesconto();
	livroDois.exibirInfo();
	
	Livro livroTres = new Livro();
	livroTres.exibirInfo();
	livroTres.setTitulo("Vaquinha pimpolha");
	livroTres.setAutor ("Rafaela Linda");
	livroTres.setNumPaginas(400);
	livroTres.setPreco(40);
	livroTres.aplicarDesconto();
	livroTres.exibirInfo();

	}

}
