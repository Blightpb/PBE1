package prjExercicio04;

public class carro extends Veiculo{
	@Override
	public void acelerar () {
		System.out.println("O Carro está acelerando");
	}
	public void frear () {
		System.out.println("O carro está freiando");
	}
}

