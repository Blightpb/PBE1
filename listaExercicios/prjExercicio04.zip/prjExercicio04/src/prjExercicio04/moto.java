package prjExercicio04;

public class moto extends Veiculo{
	@Override
	public void acelerar () {
		System.out.println("A moto está acelerando");
	}
	public void frear () {
		System.out.println("A moto está acelerando");
	}
}
