package prjExercicio04;

public class Veiculo {
	//atributos
		private String marca;
		private String modelo;
		private int velocidade;
		
		//construtores
		public Veiculo () {
			
		}
		public Veiculo (String Marca, String Modelo, int Velocidade) {
			this.marca = Marca;
			this.modelo = Modelo;
			this.velocidade = Velocidade;
			
		//getters e setters
		}
		public String getMarca() {
			return marca;
		}
		public void setMarca(String marca) {
			this.marca = marca;
		}
		public String getModelo() {
			return modelo;
		}
		public void setModelo(String modelo) {
			this.modelo = modelo;
		}
		public int getVelocidade() {
			return velocidade;
		}
		public void setVelocidade(int velocidade) {
			this.velocidade = velocidade;
		}
		
		//metodos

		public void acelerar() {
			System.out.println("Veiculo acelerando, sua velocidade agora é:");
			System.out.println(this.velocidade + 10);
		}
		public void frear() {
			System.out.println("Veiculo freando, sua velocidade agora é:");
			System.out.println(this.velocidade - 10);
		}
		
	}

