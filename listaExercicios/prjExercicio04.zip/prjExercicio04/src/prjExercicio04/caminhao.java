package prjExercicio04;

public class caminhao extends Veiculo {
	@Override
	public void acelerar () {
		System.out.println("O Caminhão está acelerando");
	}
	public void frear () {
		System.out.println("O caminhão está freiando");
	}
}
