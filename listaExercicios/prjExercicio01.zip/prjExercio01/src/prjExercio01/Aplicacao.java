package prjExercio01;

public class Aplicacao {

	public static void main(String[] args) {
		Carro carro1 = new Carro ();
		carro1.marca = "Farofinhos";
		carro1.modelo = "Farinho pro";
		carro1.ano = 2008;
		carro1.placa = "PBE";
		
	Carro carro2 = new Carro ("Big Farofinhos", "Farofinhos mini", 2008, "LIMA");
	
	carro1.exibirInfo();
	carro1.marcaCarro();
	carro1.modeloCarro();
	carro1.anoCarro();
	carro1.placaCarro();
	carro1.exibirInfo();
	
	
	carro2.exibirInfo();
	carro2.marcaCarro();
	carro2.modeloCarro();
	carro2.anoCarro();
	carro2.placaCarro();
	carro2.exibirInfo();
	
	
	}

}



