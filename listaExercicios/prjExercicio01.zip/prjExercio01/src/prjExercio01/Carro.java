package prjExercio01;

public class Carro {
	
	//Atributos
	String marca;
	String modelo;
	int ano;
	String placa;
	
	//Construtores
	
	public Carro () {
	}
	
	public Carro (String Marca, String Modelo, int Ano, String Placa) {
		this.marca = Marca;
		this.modelo = Modelo;
		this.ano = Ano;
		this.placa = Placa;
	}
	
	//Métodos
	public void marcaCarro() {
		System.out.println("marca: " + this.marca);
	}
	public void modeloCarro() {
		System.out.println("modelo: " + this.modelo);
	}
	public void anoCarro() {
		System.out.println("ano: " + this.ano);
	}
	public void placaCarro() {
		System.out.println("placa: " + this.placa);
	}
	public void exibirInfo() {
	}
}
